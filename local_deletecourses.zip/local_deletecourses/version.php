<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_deletecourses';
$plugin->version = 2025102100;        // N�mero �nico y creciente (por ejemplo, YYYYMMDDXX)
$plugin->requires = 2024040800;       // Requiere Moodle 4.4 (versi�n m�nima)
$plugin->maturity = MATURITY_ALPHA;
$plugin->release = '0.1';
$plugin->hasadminsettings = true;