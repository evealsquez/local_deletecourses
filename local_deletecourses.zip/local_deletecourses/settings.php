<?php

defined('MOODLE_INTERNAL') || die();

if ($hassiteconfig) { // Solo mostrar a administradores
    $ADMIN->add('courses', new admin_externalpage(
        'local_deletecourses',
        get_string('pluginname', 'local_deletecourses'),
        new moodle_url('/local/deletecourses/index.php'),
        'moodle/site:config'
    ));
}
