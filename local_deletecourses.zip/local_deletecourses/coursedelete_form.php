<?php

require_once($CFG->libdir.'/formslib.php');

class coursedelete_form extends moodleform {
    public function definition() {
        $mform = $this->_form;

        // Nombre del curso
        $mform->addElement('text', 'coursename', get_string('coursename', 'local_deletecourses'));
        $mform->setType('coursename', PARAM_TEXT);

        // Categoría
        $options = array('' => get_string('allcategories', 'local_deletecourses'));
        $categories = core_course_category::make_categories_list();
        $options += $categories;
        $mform->addElement('select', 'category', get_string('category'), $options);

        // Fecha desde
        $mform->addElement('date_selector', 'datestart', get_string('fromdate', 'local_deletecourses'));

        // Fecha hasta
        $mform->addElement('date_selector', 'dateend', get_string('todate', 'local_deletecourses'));

        // Estado del curso (visible/oculto)
        $mform->addElement('select', 'visible', get_string('visible'), [
            ''  => get_string('all', 'local_deletecourses'),
    '1' => get_string('visible', 'local_deletecourses'),
    '0' => get_string('hidden', 'local_deletecourses')
        ]);

        // Botón para enviar
        $mform->addElement('submit', 'submitbutton', get_string('filtercourses', 'local_deletecourses'));
    }
}