<?php
require_once('../../config.php');
require_once($CFG->dirroot.'/local/deletecourses/coursedelete_form.php');

require_login();
require_capability('moodle/site:config', context_system::instance());

$PAGE->set_url(new moodle_url('/local/deletecourses/index.php'));
$PAGE->set_context(context_system::instance());
$PAGE->set_title('Borrar cursos');
$PAGE->set_heading('Herramienta para borrar cursos');

// Procesar borrado si viene POST
if (optional_param_array('selectedcourses', null, PARAM_INT)) {
    require_sesskey(); // Seguridad

    $selectedcourses = required_param_array('selectedcourses', PARAM_INT);

    foreach ($selectedcourses as $courseid) {
        if ($courseid != SITEID) { // No borrar el sitio principal
            try {
                delete_course($courseid, false);
                \core\notification::success("Curso ID $courseid borrado correctamente.");
            } catch (Exception $e) {
                \core\notification::error("Error al borrar curso ID $courseid: " . $e->getMessage());
            }
        } else {
            \core\notification::warning("El curso principal (ID $courseid) no puede ser eliminado.");
        }
    }

    // Redirigir para evitar reenvíos
    redirect(new moodle_url('/local/deletecourses/index.php'));
}

$form = new coursedelete_form();

echo $OUTPUT->header();
echo $OUTPUT->heading('Herramienta para borrar cursos');

// Mostrar el formulario
$form->display();

// Si el formulario fue enviado y validado
if ($form->is_submitted() && $form->is_validated()) {
    global $DB;

    $data = $form->get_data();

    // Preparar la consulta básica
    $conditions = [];
    $params = [];

    // Filtro por nombre de curso
    if (!empty($data->coursename)) {
        $conditions[] = $DB->sql_like('fullname', ':coursename', false);
        $params['coursename'] = '%' . $data->coursename . '%';
    }

    // Filtro por categoría
    if (!empty($data->category)) {
        $conditions[] = 'category = :category';
        $params['category'] = $data->category;
    }

    // Filtro por fecha de inicio
    if (!empty($data->datestart)) {
        $conditions[] = 'timecreated >= :datestart';
        $params['datestart'] = $data->datestart;
    }

    // Filtro por fecha de fin
    if (!empty($data->dateend)) {
        $conditions[] = 'timecreated <= :dateend';
        $params['dateend'] = $data->dateend;
    }

    // Filtro por visibilidad
    if ($data->visible !== '') {
        $conditions[] = 'visible = :visible';
        $params['visible'] = $data->visible;
    }

    // Construir SQL
    $wheresql = '';
    if (!empty($conditions)) {
        $wheresql = 'WHERE ' . implode(' AND ', $conditions);
    }

    // Ejecutar consulta
    $sql = "SELECT id, fullname, shortname, timecreated, visible FROM {course} $wheresql ORDER BY fullname ASC";
    $courses = $DB->get_records_sql($sql, $params);

    // Mostrar resultados
    if ($courses) {
        // Iniciar formulario de borrado
        echo html_writer::start_tag('form', [
            'method' => 'post',
            'action' => new moodle_url('/local/deletecourses/index.php')
        ]);
// Agregar el token de seguridad sesskey
echo html_writer::empty_tag('input', [
    'type' => 'hidden',
    'name' => 'sesskey',
    'value' => sesskey()
]);
        // Protección contra CSRF
        echo html_writer::input_hidden_params(new moodle_url('/local/deletecourses/index.php'));

        echo html_writer::start_tag('table', ['class' => 'generaltable']);
        echo html_writer::start_tag('thead');
        echo html_writer::tag('tr',
            html_writer::tag('th', '') .
            html_writer::tag('th', 'Nombre del curso') .
            html_writer::tag('th', 'Nombre corto') .
            html_writer::tag('th', 'Fecha de creación') .
            html_writer::tag('th', 'Visible')
        );
        echo html_writer::end_tag('thead');
        echo html_writer::start_tag('tbody');

        foreach ($courses as $course) {
            echo html_writer::start_tag('tr');
            echo html_writer::tag('td',
                html_writer::empty_tag('input', [
                    'type' => 'checkbox',
                    'name' => 'selectedcourses[]',
                    'value' => $course->id
                ])
            );
            echo html_writer::tag('td', $course->fullname);
            echo html_writer::tag('td', $course->shortname);
            echo html_writer::tag('td', userdate($course->timecreated));
            echo html_writer::tag('td', $course->visible ? 'Sí' : 'No');
            echo html_writer::end_tag('tr');
        }

        echo html_writer::end_tag('tbody');
        echo html_writer::end_tag('table');

        // Botón de borrado
        echo html_writer::empty_tag('br');
        echo html_writer::tag('input', '', [
            'type' => 'submit',
            'value' => 'Borrar cursos seleccionados',
            'class' => 'btn btn-danger',
            'onclick' => "return confirm('¿Estás seguro de que deseas borrar los cursos seleccionados? Esta acción no se puede deshacer.');"
        ]);

        // Cierre del formulario
        echo html_writer::end_tag('form');
    } else {
        echo $OUTPUT->notification('No se encontraron cursos con esos filtros.', 'notifymessage');
    }
}

echo $OUTPUT->footer();