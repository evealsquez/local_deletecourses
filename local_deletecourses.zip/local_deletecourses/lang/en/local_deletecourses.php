<?php
// Nombre visible del plugin en la lista de plugins.
$string['pluginname'] = 'Delete Courses';

// Etiquetas del formulario
$string['coursename'] = 'Nombre del curso';
$string['fromdate'] = 'Fecha desde';
$string['todate'] = 'Fecha hasta';
$string['category'] = 'Categoría';
$string['visible'] = 'Visibilidad';
$string['all'] = 'Todos';
$string['hidden'] = 'Ocultos';
$string['filtercourses'] = 'Filtrar cursos';
$string['allcategories'] = 'Todas las categorías';